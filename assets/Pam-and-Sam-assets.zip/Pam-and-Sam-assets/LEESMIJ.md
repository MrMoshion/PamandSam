# Pam and Sam: losse bestanden

Studio.Edu · november 2026

## Inhoud
- **logo/**: per richting (de kamer, het voorwerp, de gedachte) het logo neutraal, Pam en Sam.
  - **SVG**: vector. De tekst is omgezet naar vormen, dus er is geen lettertype nodig. De gloed en de bol zijn echte verlopen.
  - **EPS**: vector, voor drukwerk. EPS kent geen transparantie, dus de gloed en de bol zijn in de EPS omgezet naar beeld. Gebruik waar het kan de SVG.
  - **PNG**: transparant, op 4× formaat.
  - Bij de kamer:
    - *neutraal-licht*: met de donkere achtergrond erbij;
    - *neutraal-licht-transparant*: alleen het witte logo, voor donkere ondergronden;
    - *neutraal-donker*: voor lichte ondergronden.
- **app-icoon/**: per richting als SVG, EPS en PNG (1024, 512 en 180 px). Vierkant en zonder afgeronde hoeken: het besturingssysteem rondt die zelf af.
- **presentatie/**: de hele presentatie en de drie richtingen als pdf, en alle 40 pagina's als PNG (2400 × 1600).
- **lettertypen/**: alle gebruikte lettertypen (TTF), elk met de licentie (SIL Open Font License 1.1). Vrij te gebruiken, ook commercieel. Verkoop de lettertypen niet los. "Plex" is een gereserveerde naam van IBM.
- **kleuren.md**: de kleurwaarden per richting.

## Lettertypen per richting
- **De kamer:** IBM Plex Sans Light (neutraal), IBM Plex Serif Light Italic (Pam), IBM Plex Sans Regular (Sam).
- **Het voorwerp:** EB Garamond (neutraal en Pam), Libre Franklin Light (Sam).
- **De gedachte:** Spectral Light (neutraal), Spectral Light Italic (Pam), Instrument Sans (Sam).
- **De presentatie:** Hanken Grotesk Light en Medium.

## Let op
Dit zijn de logo's zoals ze in de presentatie staan, als voorstel. Het definitieve logo volgt na de keuze voor een richting, in stap 1 (het systeem en het brandbook).
