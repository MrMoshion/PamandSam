# Kleuren

## De kamer
| Naam | Waarde |
|---|---|
| Neutraal, donker | #262626 |
| Neutraal, licht | #F4F4F2 |
| Pam, tekst | #2A2118 |
| Pam, cursor | #C9A15F |
| Pam, lamplicht | #FCF5E4 |
| Pam, avond | #1B1712 |
| Sam, tekst | #101923 |
| Sam, cursor | #4F6F92 |
| Sam, daglicht | #E8EFF6 |
| Sam, nacht | #12161B |

## Het voorwerp
| Naam | Waarde |
|---|---|
| Neutraal, tekst | #333333 |
| Pam, papier | #F6F2EA |
| Pam, grafiet | #5B5752 |
| Pam, marker | #EFE1A2 |
| Sam, papier | #FCFCFA |
| Sam, inkt | #15171B |

## De gedachte
| Naam | Waarde |
|---|---|
| Neutraal, tekst | #333333 |
| Neutraal, achtergrond | #F3F3F2 |
| Pam, tekst | #4F4744 |
| Pam, achtergrond | #F4F0EF |
| Pam, bol | rgb(150, 120, 112) |
| Sam, tekst | #1D2421 |
| Sam, achtergrond | #EEF2F0 |
| Sam, bol | rgb(70, 95, 86) |

## Presentatie (Studio.Edu)
Tekst #111111, donkergrijs #262626, wit #FFFFFF. Letter: Hanken Grotesk 300.
