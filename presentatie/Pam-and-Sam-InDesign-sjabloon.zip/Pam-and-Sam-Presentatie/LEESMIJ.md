# Pam and Sam: InDesign-sjabloon

Studio.Edu · november 2026

## Openen
1. **Installeer eerst Hanken Grotesk** (Light en Medium) uit de map `Lettertypen`. Voor de ontwerpvoorbeelden zijn geen andere lettertypen nodig, want die zitten in de beelden.
2. **Open `Pam-and-Sam-Presentatie-sjabloon.idml`** in InDesign (versie CS6 of nieuwer).
3. **Meldt InDesign ontbrekende koppelingen?** Kies dan in het paneel Koppelingen *Opnieuw koppelen* en wijs de map `Links` aan. InDesign vindt dan alle beelden in één keer.
4. **Sla het op als .indd**, of als .indt als je het als sjabloon wilt bewaren.

## Opbouw
- **41 pagina's van 1200 × 800 px** (3:2), in dezelfde volgorde als de pdf.
- **Basispagina's:**
  - *A-Studio.Edu*: met Studio.Edu linksonder;
  - *B-Leeg*: zonder iets erop.
- **Lagen:**
  - *Beeld*: de ontwerpvoorbeelden, als gekoppelde PNG op 144 ppi;
  - *Tekst*: alle tekst, bewerkbaar.
- **Alinea-stijlen:**

  | Stijl | Maat | Gebruik |
  |---|---|---|
  | Kop 44 | 44 pt | Koppen |
  | Tekst 24 | 24 pt | Gewone tekst |
  | Subtekst 18 | 18 pt | Bijschriften en labels |
  | Subtekst 18 grijs | 18 pt, 60% zwart | Grijze bijschriften |
  | Voetnoot 18 | 18 pt | Voetnoten |
  | Tabel 24 en Tabel 24 rechts | 24 pt | Tabelcellen, links of rechts uitgelijnd |
  | Tabel kop 18 grijs | 18 pt | Kopjes boven tabellen |
  | Studio.Edu | 18 pt | Het merk op de basispagina |

  Alle stijlen gebruiken Hanken Grotesk Light.
- **Kleurstalen:** de kleuren van Studio.Edu (zwart #111111, donkergrijs #262626, lijn #DDDDDA) en de kleuren van de drie richtingen.
- **Tabellen** zijn echte InDesign-tabellen. Lijnen staan alleen tussen de rijen.

## Als sjabloon gebruiken
- **Nieuwe pagina:** pas basispagina A toe. Gebruik de stijlen Kop 44, Tekst 24 en Subtekst 18, met marges van 64 px links en rechts en 56 px boven.
- **Houd je aan de presentatiestijl:** drie maten, geen lijnen als opsmuk, en voetnoten op dezelfde hoogte.

## Let op
Het bestand is buiten InDesign gemaakt en getest in een ander programma dat IDML leest. Loop het één keer na in InDesign. Op een paar plekken kan een regel anders afbreken dan in de pdf. Zet het dan recht met de breedte van het tekstkader.
